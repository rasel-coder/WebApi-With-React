﻿namespace StudentForm.Service;

public class StudentService : IStudentService
{

}

public interface IStudentService
{

}
