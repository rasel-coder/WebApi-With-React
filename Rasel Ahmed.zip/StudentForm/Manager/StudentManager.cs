﻿namespace StudentForm.Manager;

public class StudentManager : IStudentManager
{

}

public interface IStudentManager
{

}
